"""Game namespace package."""
